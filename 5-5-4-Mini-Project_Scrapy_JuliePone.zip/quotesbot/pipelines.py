# -*- coding: utf-8 -*-


class QuotesbotPipeline(object):
    def process_item(self, item, spider):
        return item
