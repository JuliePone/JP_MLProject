# This package will contain the spiders of Scrapy project

