import sqlite3
conn = sqlite3.connect('quotes.db')

c = conn.cursor()

# Create table
c.execute('''CREATE TABLE quotes
             (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, quote text, author text, tags text)''')

# Read the JSON data


# Insert a row of data
c.execute("INSERT INTO quotes VALUES ('2006-01-05','BUY','RHAT',100,35.14)")

# Save (commit) the changes
conn.commit()

conn.close()